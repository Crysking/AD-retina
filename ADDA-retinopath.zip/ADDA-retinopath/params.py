"""Params for DA."""

# params for dataset and data loader
data_root = "data"
dataset_mean_value = 0.5
dataset_std_value = 0.5
dataset_mean = (dataset_mean_value, dataset_mean_value, dataset_mean_value)
dataset_std = (dataset_std_value, dataset_std_value, dataset_std_value)
batch_size = 32#50
image_size = 224#64#28
#==========discriminator==========
leakiness=0.2 #'leaky relu leakiness'
D_conv_block_size=1
#=================================

# params for source dataset

src_dataset_path = "/data/source/"
src_dataset = 'source'
src_encoder_restore = "/DA_model/Resnet18/ADDA-source-encoder-final.pt"
src_classifier_restore = "/DA_model/Resnet18/ADDA-source-classifier-final.pt"
src_model_trained = True

# params for target dataset
tgt_dataset = "target"
tgt_dataset_path = "/data/target"
tgt_encoder_restore = "/DA_model/Resnet18/ADDA-target-encoder-16-100.pt"
tgt_model_trained = True
logger_pretrain_train = './logs/Resnet18/pretrain/train'
logger_pretrain_val = './logs/Resnet18/pretrain/val'
logger_adapt='./logs/Resnet18/adapt'

# params for setting up models

model_root = "/data/DA_model/Resnet18"
d_input_dims = 1000
d_hidden_dims = 500 #1000
d_output_dims = 2
d_model_restore = "/DA_model/Resnet18/ADDA-critic-16-100.pt"
# params for training network
num_gpu = 2
num_epochs_pre = 5  #1   #40#100#pretrain
log_step_pre = 100 #100
eval_step_pre = 200#500
save_step_pre = 10
num_epochs = 20   #10#2000#adapt
log_step = 50#100
eval_step = 100
save_step = 5     #save model every 5 epoches
manual_seed = None

# params for optimizing models
d_learning_rate = 1e-5# 1e-4
c_learning_rate = 1e-5#1e-4
beta1 = 0.5
beta2 = 0.9
