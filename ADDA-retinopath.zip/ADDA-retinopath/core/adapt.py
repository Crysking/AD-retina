"""Adversarial adaptation to train target encoder."""

import os

import torch
import torch.optim as optim
from torch import nn

import params
from utils import make_variable,set_requires_grad
from logger import Logger
import numpy as np


def train_tgt(src_encoder, tgt_encoder, critic,
              src_data_loader, tgt_data_loader,tgt_data_loader_eval,logger_train,src_classifier):
    """Train encoder for target domain."""
    ####################
    # 1. setup network #
    ####################

    # set train state for Dropout and BN layers
    tgt_encoder.train()
    critic.train()

    # setup criterion and optimizer
    criterion = nn.CrossEntropyLoss()
    optimizer_tgt = optim.Adam(tgt_encoder.parameters(),
                               lr=params.c_learning_rate,
                               betas=(params.beta1, params.beta2))
    optimizer_critic = optim.Adam(critic.parameters(),
                                  lr=params.d_learning_rate,
                                  betas=(params.beta1, params.beta2))
#    optimizer_tgt = optim.SGD(tgt_encoder.parameters(), lr=params.c_learning_rate, momentum=0.9)
#    optimizer_critic = optim.SGD(critic.parameters(), lr=params.d_learning_rate, momentum=0.9)
    len_data_loader = min(len(src_data_loader), len(tgt_data_loader))

    ####################
    # 2. train network #
    ####################

    best_acc=0
    data=open(f"./result.txt",'w')
    for epoch in range(params.num_epochs):
        # zip source and target data pair
        data_zip = enumerate(zip(src_data_loader, tgt_data_loader))
        for step, ((images_src, _), (images_tgt, _)) in data_zip:
            ###########################
            # 2.1 train discriminator #
            ###########################

            # make images variable
#            set_requires_grad(tgt_encoder, requires_grad=False)
#            set_requires_grad(critic,requires_grad=True)
            images_src = make_variable(images_src)
            images_tgt = make_variable(images_tgt)
            # extract and concat features
            
            acc_all = 0
            for D_step in range(5):
                # zero gradients for optimizer
                optimizer_critic.zero_grad()
                feat_src = src_encoder(images_src)
                feat_tgt = tgt_encoder(images_tgt)
                feat_concat = torch.cat((feat_src, feat_tgt), 0)
    #            print('The feat_concat is:{}'.format(feat_concat))
                
                # predict on discriminator
                pred_concat = critic(feat_concat.detach())
    
                # prepare real and fake label
                label_src = make_variable(torch.ones(feat_src.size(0)).long())
                label_tgt = make_variable(torch.zeros(feat_tgt.size(0)).long())
                label_concat = torch.cat((label_src, label_tgt), 0)
    #            print('the label_concat is:{}'.format(label_concat))
    
                # compute loss for critic
    #            print("the label is:{}".format(label_concat))
#                print("The probability is:{}".format(pred_concat))
                loss_critic = criterion(pred_concat, label_concat)
                loss_critic.backward()
    
                # optimize critic
                optimizer_critic.step()

                pred_cls = torch.squeeze(pred_concat.max(1)[1])
#                print('The prediction is:{}'.format(pred_cls))
    #            print('the pred_cls is :{}'.format(pred_cls))
                acc_step= (pred_cls == label_concat).float().mean()
                
                acc_all += acc_step
            acc=acc_all / 5
#            print('The acc is:{}'.format(acc))    

            ############################
            # 2.2 train target encoder #
            ############################

            # zero gradients for optimizer
#            optimizer_critic.zero_grad()
#            set_requires_grad(tgt_encoder, requires_grad=True)
#            set_requires_grad(critic,requires_grad=False)
                        
            # extract and target features
            optimizer_tgt.zero_grad()
            feat_tgt = tgt_encoder(images_tgt)

            # predict on discriminator
            pred_tgt = critic(feat_tgt)    #discrimininator

            # prepare fake labels
            label_tgt = make_variable(torch.ones(feat_tgt.size(0)).long())

            # compute loss for target encoder
            loss_tgt = criterion(pred_tgt, label_tgt)
            loss_tgt.backward()

            # optimize target encoder
            optimizer_tgt.step()
            #==============tensorboard====================================================
            epoch_step=epoch*len(tgt_data_loader)
            info = { 'critic_loss': loss_critic.item(), 'generator_loss': loss_tgt.item() }

            for tag, value in info.items():
                logger_train.scalar_summary(tag, value, epoch_step+step+1)

            #######################
            # 2.3 print step info #
            #######################
#            print('The dicriminator loss is:{},the generator loss is:{}'.format(loss_critic.item(),loss_tgt.item()))
            if ((step + 1) % params.log_step == 0):
                print("Epoch [{}/{}] Step [{}/{}]:"
                      "d_loss={:.5f} g_loss={:.5f} acc={:.5f}"
                      .format(epoch + 1,
                              params.num_epochs,
                              step + 1,
                              len_data_loader,
                              loss_critic.item(),
                              loss_tgt.item(),
                              acc.item()))
                
            report1 = ' Step: {} The dicriminator loss is: {:.4f} the generator loss is: {:.4f} || /n'.format(step,
                                                                                                      loss_critic.item(),
                                                                                                      loss_tgt.item())
            if ((step + 1) % params.eval_step == 0):
                acc = eval_tgt(tgt_encoder, src_classifier, tgt_data_loader_eval,fold='ADDA')
                if acc>best_acc:
        #############################
        # 2.4 save model parameters #
        #############################
#        if ((epoch + 1) % params.save_step == 0):
                    torch.save(critic.state_dict(), os.path.join(
                        params.model_root,
                        "ADDA-critic-{}-{}.pt".format(epoch + 1,step+1)))
                    torch.save(tgt_encoder.state_dict(), os.path.join(
                        params.model_root,
                        "ADDA-target-encoder-{}-{}.pt".format(epoch + 1,step+1)))
                    best_acc=acc
            report2='Step:{} The test accuracy is:{:.4f}'.format(step,acc)
            data.write(report1)
            data.write(report2)
        

    torch.save(critic.state_dict(), os.path.join(
        params.model_root,
        "ADDA-critic-final.pt"))
    torch.save(tgt_encoder.state_dict(), os.path.join(
        params.model_root,
        "ADDA-target-encoder-final.pt"))
    data.close()
    return tgt_encoder




def eval_tgt(encoder, classifier, data_loader,fold='ADDA'):
    """Evaluation for target encoder by source classifier on target dataset."""
    # set eval state for Dropout and BN layers
    encoder.eval()
    classifier.eval()

    # init loss and accuracy
    loss = 0
    acc = 0

    # set loss function
    criterion = nn.CrossEntropyLoss()

    label_all = torch.zeros(params.batch_size)
    probs = torch.zeros(1,2)
    # evaluate network
    for (images, labels) in data_loader:
        images = make_variable(images, volatile=True)
        labels = make_variable(labels).squeeze_()
        label_all=np.append(label_all,labels.data.cpu().numpy(),axis=0)


        with torch.no_grad():
            preds = classifier(encoder(images))

            probs=np.append(probs, preds.data.cpu().numpy(),axis=0)

            loss = criterion(preds, labels)
        pred_cls = preds.data.max(1)[1]

        acc += pred_cls.eq(labels.data).cpu().sum()

    acc = acc.float()
    loss /= len(data_loader)

    acc /= len(data_loader.dataset)
    print("Avg Loss = {}, Avg Accuracy = {:2%}".format(loss, acc))
    return acc
