"""Test script to classify target data."""

import torch
import torch.nn as nn
import matplotlib.pyplot as plt 
from sklearn.metrics import roc_curve
from sklearn.metrics import auc
import numpy as np
import itertools
from sklearn.metrics import confusion_matrix
import params

from utils import make_variable

def generate_roc(y_test, y_score, pos_label = 0,fold='ADDA'):
  fpr, tpr, _ = roc_curve(y_test, y_score, pos_label = pos_label)
  roc_auc = auc(fpr, tpr)
  plt.figure()
  plt.plot(fpr, tpr, color='blue', label="ROC curve (auc = %0.4f)" % roc_auc)
  plt.plot([0, 1], [0, 1], "k--",color='red')
  plt.xlim([0.0, 1.05])
  plt.ylim([0.0, 1.05])
  plt.xlabel("False Positive Rate")
  plt.ylabel("True Positive Rate")
  plt.title("Receiver operating characteristic curve")
  plt.legend(loc="lower right")
  plt.savefig(f'./snapshots/Test_result/{fold}_roc.png', dpi=600)
  plt.show()
  return roc_auc

def plot_confusion_matrix(cm, classes,
                          normalize=False,
                          title='Confusion matrix',
                          fold='ADDA',cmap=plt.cm.Blues):
    """
    This function prints and plots the confusion matrix.
    Normalization can be applied by setting `normalize=True`.
    """
    if normalize:
        cm = cm.astype('float') / cm.sum(axis=1)[:, np.newaxis]
        print("Normalized confusion matrix")
    else:
        print('Confusion matrix, without normalization')

    print(cm)

    plt.imshow(cm, interpolation='nearest', cmap=cmap)
    plt.title(title)
    plt.colorbar()
    tick_marks = np.arange(len(classes))
    plt.xticks(tick_marks, classes, rotation=45)
    plt.yticks(tick_marks, classes)

    fmt = '.2f' if normalize else 'd'
    thresh = cm.max() / 2.
    for i, j in itertools.product(range(cm.shape[0]), range(cm.shape[1])):
        plt.text(j, i, format(cm[i, j], fmt),
                 horizontalalignment="center",
                 color="white" if cm[i, j] > thresh else "black")

    plt.ylabel('True label')
    plt.xlabel('Predicted label')
    plt.tight_layout()
    plt.savefig(f'./snapshots/Test_result/{fold}_matrix.png', dpi=600)
    plt.show()
    return cm


def eval_tgt(encoder, classifier, data_loader,fold='ADDA'):
    """Evaluation for target encoder by source classifier on target dataset."""
    # set eval state for Dropout and BN layers
    encoder.eval()
    classifier.eval()

    # init loss and accuracy
    loss = 0
    acc = 0

    # set loss function
    criterion = nn.CrossEntropyLoss()

    label_all = torch.zeros(params.batch_size)
    probs = torch.zeros(1,2)
    # evaluate network
    for (images, labels) in data_loader:
        images = make_variable(images, volatile=True)
        labels = make_variable(labels).squeeze_()
#        print('The shape of labels:{}'.format(labels.shape))
#        print('The shape of label_all:{}'.format(label_all.shape))
        label_all=np.append(label_all,labels.data.cpu().numpy(),axis=0)
        
#        labels = make_variable(labels)
        

        with torch.no_grad():
            preds = classifier(encoder(images))
#            print('The shape of preds is:{}'.format(preds.data.cpu().numpy().shape))
            probs=np.append(probs, preds.data.cpu().numpy(),axis=0)
#            print("THe probs is:{}".format(probs))
#            print("The preds is:{}".format(preds))
#            print("The labels is:{}".format(labels))
#            loss += criterion(preds, labels).item()
#            print("The loss is:{}".format(loss))
            loss = criterion(preds, labels)
#            print("The final loss is:{}".format(loss))
            
#        print("The loss is :{}".format(loss))

        pred_cls = preds.data.max(1)[1]
#        print('The preds is:{}'.format(preds))
        acc += pred_cls.eq(labels.data).cpu().sum()
#    print('The label size is:{}'.format(label_all[16:].shape)) 
#    print('The prob size is:{}'.format(probs[1:,[0]].shape))
    acc = acc.float()
    loss /= len(data_loader)
#    print("The length of data_loader is:{}".format(len(data_loader)))
    acc /= len(data_loader.dataset)
    c=params.batch_size
    print("Avg Loss = {}, Avg Accuracy = {:2%}".format(loss, acc))
    AUC = generate_roc(label_all[c:], probs[1:,[0]], pos_label = 0, fold=fold)
    print("Final Model AUC: {:0.2f}%".format(AUC * 100))
    class_idx = np.argmax(probs[1:],axis=1) 
    cnf_matrix = confusion_matrix(label_all[c:], class_idx)
    np.set_printoptions(precision=1)
    class_names = ['Abnormal','Normal']

# Plot non-normalized confusion matrix
#    class_names=image_lists.keys()
    plt.figure()
    plot_confusion_matrix(cnf_matrix, classes=class_names,
                          title='Confusion matrix, without normalization',fold=fold)
