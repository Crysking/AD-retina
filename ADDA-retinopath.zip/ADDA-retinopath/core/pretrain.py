"""Pre-train encoder and classifier for source dataset."""

import torch.nn as nn
import torch.optim as optim
import torch

import params
from utils import make_variable, save_model
#from logger import Logger
#import tflib as lib

#logger_train = Logger('/home/amax/Documents/WJs_code/Illness_data/cross_validation/logs/train')

def train_src(encoder, classifier, data_loader,data_loader_eval,logger_train,logger_val):
    """Train classifier for source domain."""
    ####################
    # 1. setup network #
    ####################

    # set train state for Dropout and BN layers
    encoder.train()
    classifier.train()

    # setup criterion and optimizer
    optimizer = optim.Adam(
        list(encoder.parameters()) + list(classifier.parameters()),
        lr=params.c_learning_rate,
        betas=(params.beta1, params.beta2))
    criterion = nn.CrossEntropyLoss()

    ####################
    # 2. train network #
    ####################
    best_acc=0

    for epoch in range(params.num_epochs_pre):
#        for step, (images, labels) in enumerate(data_loader):
        acc = 0
        for step, data in enumerate(data_loader):
            
            images, labels = data
#            print('The image is:{}'.format(images))
            # make images and labels variable
            images = make_variable(images)
            labels = make_variable(labels.squeeze_())
            
#            print("The label is:{}".format(labels))
            

            # zero gradients for optimizer
            optimizer.zero_grad()

            # compute loss for critic
#            with torch.no_grad():
            try:
                outputs = classifier(encoder(images))
            except RuntimeError as exception:
                if "out of memory" in str(exception):
                    print("WARNING: out of memory")
                    if hasattr(torch.cuda, 'empty_cache'):
                        torch.cuda.empty_cache()
                else:
                    raise exception

#            print("The size of labels is:{}".format(labels))
#            print("The pred size is:{}".format(preds))
#            loss = criterion(preds, labels).view(-1)
#            print('The preds is:{}'.format(preds))
            preds = outputs.data.max(1)[1]
            loss = criterion(outputs, labels).view(-1)
#            print('The acc is:{},the acc type is{}'.format(acc,type(acc)))
            acc += preds.eq(labels.data).cpu().sum()
#            print('The acc is:{},The data length is:{}'.format(acc,len(data_loader.dataset)))
            
            
#            print("The size of labels is:{}".format(labels))
#            print('The preds is:{}'.format(preds))
#            acc = torch.sum(preds == labels.data).float()

            # optimize source classifier
            loss.backward()
            optimizer.step()
             # ================================================================== #
                #                        Tensorboard Logging                         #
                # ================================================================== #
        
                # 1. Log scalar values (scalar summary)
            
#                        print('Logs saved')
#                        print('Logs saved')

            # print step info
            
            accuracy=acc.float()
#            
#            
            info = { 'train_loss': loss.item(), 'train_accuracy': accuracy }

            for tag, value in info.items():
                logger_train.scalar_summary(tag, value, step)
           
            if ((step+1)  % params.log_step_pre == 0):
                accuracy /= (params.batch_size*params.log_step_pre)
                
            # ================================================================== #
            #                        Tensorboard Logging                         #
            # ================================================================== #
            
            #====================================================================    
                print("Epoch [{}/{}] Step [{}/{}]: loss={}, acc={}"
                      .format(epoch + 1,
                              params.num_epochs_pre,
                              step + 1,
                              len(data_loader),
                              loss.item(),
                              accuracy))
                acc=0

        # eval model on test set
#        if ((epoch + 1) % params.eval_step_pre == 0):
            epoch_step=epoch*len(data_loader)
            if ((step + 1) % params.eval_step_pre == 0):
                Eval_acc=eval_src(encoder, classifier, data_loader_eval,True,logger_val,epoch_step,step)

        # save model parameters
#        if ((epoch + 1) % params.save_step_pre == 0):
                if Eval_acc > best_acc:
                    save_model(encoder, "ADDA-source-encoder-{}-{}.pt".format(epoch + 1,step))
                    save_model(
                        classifier, "ADDA-source-classifier-{}-{}.pt".format(epoch + 1,step))
                    best_acc = Eval_acc
#        lib.plot.plot(r'E:\LabratoryProject\MachineLearning\OCT-retinopathy\pytorch-adda-master\tmp\mnist\train loss', loss.cpu().data.numpy())

    # # save final model
    save_model(encoder, "ADDA-source-encoder-final.pt")
    save_model(classifier, "ADDA-source-classifier-final.pt")

    return encoder, classifier


def eval_src(encoder, classifier, data_loader,logs,logger_val,epoch,step):
    """Evaluate classifier for source domain."""
    # set eval state for Dropout and BN layers
    encoder.eval()
    classifier.eval()

    # init loss and accuracy
    loss = 0
    acc = 0

    # set loss function
    criterion = nn.CrossEntropyLoss()

    # evaluate network
    for (images, labels) in data_loader:
        images = make_variable(images, volatile=True)
        labels = make_variable(labels)

        with torch.no_grad():
            preds = classifier(encoder(images))
            loss += criterion(preds, labels).item()

        pred_cls = preds.data.max(1)[1]
        acc += pred_cls.eq(labels.data).cpu().sum()
     
    
        
    acc = acc.float()
#    print("The eval acc is:{},eval loss is:{}".format(acc,))
    loss /= len(data_loader)
    acc /= len(data_loader.dataset)
    if logs == True:
        info = { 'val_loss': loss, 'val_accuracy': acc }
    
        for tag, value in info.items():
            logger_val.scalar_summary(tag, value, epoch+step+1)
    

    print("Avg Loss = {}, Avg Accuracy = {:2%}".format(loss, acc))
    return acc
