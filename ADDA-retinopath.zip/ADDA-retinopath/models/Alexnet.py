# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 16:42:23 2019

@author: crysk
"""

from torchvision import models
import torch.nn.functional as F
from torch import nn


class AlexnetEncoder(nn.Module):
    def __init__(self):
        """Init LeNet encoder."""
        super(AlexnetEncoder, self).__init__()

        self.restored = False
        self.Encoder = models.alexnet(pretrained=True)
#        
        
    def forward(self,input):
        feat = self.Encoder(input)
        return feat
    
class AlexnetClassifier(nn.Module):
    """LeNet classifier model for ADDA."""

    def __init__(self):
        """Init LeNet encoder."""
        super(AlexnetClassifier, self).__init__()
#        model=self.Encoder
#        num_ftrs = model.classifier[6].in_features
        self.fc2 = nn.Linear(1000, 2)

    def forward(self, feat):
        """Forward the LeNet classifier."""
        out = F.dropout(F.relu(feat), training=self.training)
        out = self.fc2(out)
        return out
