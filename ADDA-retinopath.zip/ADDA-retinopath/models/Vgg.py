# -*- coding: utf-8 -*-
"""
Code for vgg encoder
@author: crysk
"""

from torchvision import models
import torch.nn.functional as F
from torch import nn


class VggEncoder(nn.Module):
    def __init__(self):
        """Init LeNet encoder."""
        super(VggEncoder, self).__init__()

        self.restored = False
#        self.Encoder = models.vgg16(pretrained=True)
        self.Encoder = models.resnet18(pretrained=True)
    def forward(self,input):
        feat = self.Encoder(input)
        return feat
    
class VggClassifier(nn.Module):
    """LeNet classifier model for ADDA."""

    def __init__(self):
        """Init LeNet encoder."""
        super(VggClassifier, self).__init__()
#        model=self.Encoder
#        num_ftrs = model.fc.in_features
        self.fc2 = nn.Linear(1000, 2)

    def forward(self, feat):
        """Forward the LeNet classifier."""
        out = F.dropout(F.relu(feat), training=self.training)
        out = self.fc2(out)
        return out
