#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Code for my discriminator

"""
from torch import nn
import params as opt
import numpy as np
import torch

class conv_block(nn.Module):
    def __init__(self, in_channels, out_channels, ngpu=1, kernel_size=3, stride=1, padding=1, leakiness=0.2):
        super(conv_block, self).__init__()
        self.ngpu = ngpu
        self.main = nn.Sequential(
            # batch_size x in_channels x H x W
            nn.Conv2d(in_channels, out_channels, kernel_size=kernel_size, stride=stride, padding=padding, bias=False),
            nn.BatchNorm2d(out_channels),
            nn.LeakyReLU(leakiness, inplace=False)
            # batch_size x out_channels x H' x W'
        )

    def forward(self, inputs):
        if isinstance(inputs.data, torch.cuda.FloatTensor) and self.ngpu > 1:
            output = nn.parallel.data_parallel(self.main, inputs, range(self.ngpu))
        else:
            output = self.main(inputs)
        return output

class M_Discriminator(nn.Module):
    """Discriminator model for source domain."""

    def __init__(self, input_dims, hidden_dims, output_dims,kernel_size=3, stride=2, padding=1):
        """Init discriminator."""
        super(M_Discriminator, self).__init__()
        self.kernel_size = kernel_size
        self.stride = stride
        self.padding = padding
        self.ngpu = opt.num_gpu

        self.restored = False
        
        layers, out_channels, projection_size  = self.make_layers([224,224,3], 64, 7,opt)

        self.main = nn.Sequential(
            # batch_size x in_channels x 64 x 64
            nn.Linear(input_dims, 3),
            nn.ReLU(),
            nn.Conv2d(3, 64, kernel_size=3, stride=1, padding=1, bias=True),
            # nn.BatchNorm2d(opt.ndf),
            nn.LeakyReLU(opt.leakiness, inplace=False),
            *layers
            
#            nn.Linear(input_dims, hidden_dims),
#            nn.ReLU(),
#            nn.Linear(hidden_dims, hidden_dims),
#            nn.ReLU(),
#            nn.Linear(hidden_dims, output_dims),
#            nn.LogSoftmax()
#            nn.Softmax()
        )
        self.fully_connected = nn.Linear(projection_size*projection_size*out_channels, output_dims)
    
    
    def make_layers(self, image_size, filters, projection_size, opt):
        feature_map = image_size[0]     # H or W
        layers = []
        in_channels = filters
        out_channels = in_channels
        while feature_map > projection_size:
            out_channels = in_channels * 2
            for _ in range(1, opt.D_conv_block_size):
                layers.append(conv_block(in_channels, out_channels, ngpu=opt.num_gpu,
                              kernel_size=3, stride=1, padding=1, leakiness=opt.leakiness))
                in_channels = out_channels
            layers.append(conv_block(in_channels, out_channels, opt.num_gpu,
                          self.kernel_size, self.stride, self.padding, opt.leakiness))
#            layers.append(inject_noise(opt, dropout=True))
            in_channels = out_channels
            feature_map = int(np.floor(np.divide(feature_map + 2*self.padding - self.kernel_size, self.stride) + 1))

        assert feature_map == projection_size
        return layers, out_channels, feature_map
    
    def forward(self, input):
        """Forward the discriminator."""
        output = self.main(input)
        output = output.view(output.size(0), -1)
        output = self.fully_connected(output)
        return output
#        return out


    
