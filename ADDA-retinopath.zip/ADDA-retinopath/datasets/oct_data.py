# -*- coding: utf-8 -*-
"""
Created on Mon Sep  9 09:32:50 2019

@author: crysk
"""
from torchvision import datasets, transforms
import os
import torch
import params


def get_dateset(name,train):
    if train == True:
        mode = 'train'
    else:
        mode = 'val'
    data_transforms = {
                'train': transforms.Compose([
                    # 裁剪到224,224
                    transforms.RandomResizedCrop(params.image_size),
                    # 随机水平翻转给定的PIL.Image,概率为0.5。即：一半的概率翻转，一半的概率不翻转。
                    transforms.RandomHorizontalFlip(),
                    # transforms.ColorJitter(0.05, 0.05, 0.05, 0.05),  # HSV以及对比度变化
                    transforms.ToTensor(),
                    # 把一个取值范围是[0,255]的PIL.Image或者shape为(H,W,C)的numpy.ndarray，转换成形状为[C,H,W]，取值范围是[0,1.0]的FloadTensor
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                ]),
                'val': transforms.Compose([
                    transforms.Resize(256),
                    transforms.CenterCrop(params.image_size),
                    transforms.ToTensor(),
                    transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])
                ]),
            }
    
    image_datasets = {x: datasets.ImageFolder(os.path.join(name, x),
                                                      data_transforms[x])
                                              for x in [mode]}
    dataloaders = {x: torch.utils.data.DataLoader(image_datasets[x], batch_size=params.batch_size,
                                                          shuffle=True, pin_memory=False)
                                               for x in [mode]}
    return dataloaders[mode]